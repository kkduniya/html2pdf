<style type="text/css">
<!--
div {
    border: solid 2mm red;
}

div.content-1 {
    background: green;
}


div.content-2 {
    background: blue;
}

-->
</style>
<page>
    <div class="content-[[page_cu]]">Page [[page_cu]]</div>
</page>
<page>
    <div class="content-[[page_cu]]">Page [[page_cu]]</div>
</page>
